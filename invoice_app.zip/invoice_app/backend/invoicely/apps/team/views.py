from rest_framework import viewsets

from .serializers import TeamSerializer
from .models import Team

from django.core.exceptions import PermissionDenied

class TeamViewSet(viewsets.ModelViewSet):
    serializer_class = TeamSerializer
    queryset = Team.objects.all()

    def get_queryset(self):
        teams = self.request.user.teams.all()

        if not teams:
            Team.objects.create(name='', org_number='', created_by=self.request.user)
        
        return self.queryset.filter(created_by=self.request.user)
    
    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)
    
    def perform_update(self, serializer):
        obj = self.get_object()

        if self.request.user != obj.created_by:
            raise PermissionDenied('Wrong object owner')

        serializer.save()



# Dieser Code definiert ein ViewSet für die Behandlung von CRUD-Operationen (Create, Retrieve, Update, Delete) im Zusammenhang
# mit dem Modell "Team" in Django mit dem Django Rest Framework (DRF).

# Zunächst werden die erforderlichen Module importiert, darunter das `viewsets`-Modul aus dem DRF für die Definition von ViewSets,
# das `TeamSerializer`-Modul zum Serialisieren und Deserialisieren von Team-Objekten, und das `Team`-Modul, das das Django-Modell für
# Teams repräsentiert. Es wird auch das `PermissionDenied`-Modul aus Django importiert, um eine Berechtigungsfehlermeldung zu erzeugen.

# Der Code definiert dann die Klasse `TeamViewSet`, die von `viewsets.ModelViewSet` erbt. Durch die Vererbung erhält die Klasse bereits
# die grundlegenden CRUD-Funktionen, die im ViewSet benötigt werden.

# In der Klasse werden verschiedene Methoden definiert, um das Verhalten des ViewSets anzupassen:

# - `serializer_class`: Hier wird der Serializer `TeamSerializer` für das ViewSet festgelegt. Der Serializer wird verwendet, um die Daten des
# Teams zu serialisieren und zu deserialisieren.

# - `queryset`: Hier wird die Abfrage festgelegt, die alle Teams aus der Datenbank abruft. `Team.objects.all()` gibt eine QuerySet-Instanz zurück,
# die alle Team-Objekte enthält.

# - `get_queryset`: Diese Methode wird überschrieben, um das Standardqueryset zu ändern. Hier wird ein neues QuerySet erstellt, das nur die Teams
# des aktuellen Benutzers enthält. Zuerst werden alle Teams des Benutzers aus der `request`-Instanz abgerufen. Wenn der Benutzer keine Teams hat
# (d.h., die Liste `teams` ist leer), wird ein neues Team-Objekt erstellt und dem Benutzer zugeordnet. Schließlich wird das QuerySet gefiltert,
# um nur Teams zurückzugeben, die vom aktuellen Benutzer erstellt wurden.

# - `perform_create`: Diese Methode wird aufgerufen, wenn ein neues Team erstellt wird. Hier wird der erstellende Benutzer dem Serializer hinzugefügt,
# indem `created_by` auf `self.request.user` gesetzt wird.

# - `perform_update`: Diese Methode wird aufgerufen, wenn ein vorhandenes Team aktualisiert wird. Zuerst wird das zu aktualisierende Objekt abgerufen.
# Dann wird überprüft, ob der aktuelle Benutzer der Ersteller des Teams ist. Wenn nicht, wird eine `PermissionDenied`-Ausnahme ausgelöst, um anzuzeigen,
# dass der Benutzer nicht berechtigt ist, das Team zu bearbeiten. Andernfalls wird der Serializer verwendet, um die Aktualisierung des Teams durchzuführen.

# Insgesamt ermöglicht dieser Code die Anpassung des Verhaltens des ViewSets für Teams, einschließlich der Filterung der Teams nach dem Ersteller und der
# Überprüfung der Berechtigungen für die Aktualisierung.