from django.urls import path, include

from rest_framework.routers import DefaultRouter


from .views import TeamViewSet

router = DefaultRouter()

router.register("teams", TeamViewSet, basename="teams")

urlpatterns = [
    path('',include(router.urls)), ]





# Dieser Code ist ein Beispiel für die Konfiguration von URLs in Django, insbesondere für die Verwendung des Django Rest Framework (DRF).

# Zunächst werden die erforderlichen Module importiert. Die `path`-Funktion wird verwendet, um URL-Pfade in Django zu definieren,
# während `include` verwendet wird, um andere URLs einzuschließen. Der `DefaultRouter` aus dem DRF wird importiert, um die URL-Routing-Funktionalität bereitzustellen. Schließlich wird der `TeamViewSet` importiert, der ein ViewSet ist, das in diesem Beispiel für die Verarbeitung der Anfragen im Zusammenhang mit Teams verwendet wird.

# Dann wird ein `DefaultRouter`-Objekt `router` erstellt. Dieser Router wird verwendet, um automatisch die erforderlichen URLs für das
# ViewSet `TeamViewSet` zu generieren. Durch den Aufruf der `register`-Methode des Routers wird das `TeamViewSet` mit dem Namen "teams" registriert. Dies bedeutet, dass der Router automatisch URLs für Aktionen wie das Auflisten, Erstellen, Aktualisieren und Löschen von Teams generieren wird.

# Die Variable `urlpatterns` ist eine Liste von URL-Mustern für die Anwendung. In diesem Beispiel wird ein einzelner Eintrag definiert,
# der den Wurzelpfad (`''`) mit den generierten URLs des Routers mithilfe der `include`-Funktion verbindet. Dies bedeutet, dass alle URLs,
# die mit dem Wurzelpfad der Anwendung übereinstimmen, an den Router weitergeleitet werden, der dann die entsprechenden ViewSet-Methoden aufruft,
# um die Anfragen zu verarbeiten.

# Insgesamt ermöglicht dieser Code den einfachen Aufbau von URLs für CRUD-Operationen (Create, Retrieve, Update, Delete) im Zusammenhang mit Teams
# mithilfe des DRF und Django.