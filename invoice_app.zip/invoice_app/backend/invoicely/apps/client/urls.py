from django.urls import path, include

from rest_framework.routers import DefaultRouter

from .views import ClientViewSet


#router = DefaultRouter(): Erstellt eine Instanz des DefaultRouter-Objekts namens router. Der Router wird verwendet,
# um automatisch URL-Routen für die im Router registrierten ViewSets zu generieren.
router = DefaultRouter()

#router.register('clients', ClientViewSet, basename='clients'): Registriert den ClientViewSet im Router. Die Methode register
# wird verwendet, um das ViewSet dem Router hinzuzufügen. Der erste Parameter 'clients' gibt den Namen der URL an, die den
# ClientViewSet bedient. Der zweite Parameter ClientViewSet gibt das ViewSet an, das für die angegebene URL verwendet werden soll.
# Der dritte Parameter basename='clients' legt den Basisnamen für die generierten URLs fest.
router.register('clients', ClientViewSet, basename='clients')


#urlpatterns = [path('', include(router.urls))]: Definiert die URL-Konfiguration für die Django-Anwendung. Die Liste urlpatterns
# enthält ein einzelnes Element, das path('', include(router.urls)) ist. Hierbei handelt es sich um den Haupt-URL-Pfad für die
# Anwendung, der alle URLs enthält, die vom Router generiert werden. Die include-Funktion wird verwendet, um die generierten URLs
# des Routers in den Haupt-URL-Pfad einzuschließen.
urlpatterns = [
    path('', include(router.urls))
]




# Zusammenfassend konfiguriert der Code den Router mit dem ClientViewSet und generiert automatisch URL-Routen für die API-Ansichten
# des Client-Modells. Diese Routen werden dann in den Haupt-URL-Pfad der Django-Anwendung eingebunden. Dadurch werden die definierten
# API-Endpunkte für die Client-Ansichten verfügbar gemacht.