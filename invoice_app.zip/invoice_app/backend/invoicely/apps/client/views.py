# # from django.shortcuts import render: Importiert die Funktion render aus dem Django-Paket django.shortcuts. 
# # Diese Funktion wird verwendet, um eine HTTP-Antwort zu generieren, die ein gerendertes HTML-Template enthält.
# from django.shortcuts import render
# # from rest_framework import viewsets: Importiert die viewsets-Klasse aus dem Django-Paket rest_framework. Die viewsets-Klasse 
# # ist eine Komponente des Django REST Frameworks, die eine praktische Art und Weise bietet, API-Ansichten zu erstellen.
# from rest_framework import viewsets
# #from .serializers import ClientSerializer: Importiert den ClientSerializer aus demselben Verzeichnis (Paket) wie die aktuelle Datei.
# # Der Serializer wird verwendet, um das Client-Modell in JSON oder andere Datenformate umzuwandeln.
# from .serializers import ClientSerializer
# #from .models import Client: Importiert das Client-Modell aus demselben Verzeichnis (Paket) wie die aktuelle Datei. 
# # Das Modell repräsentiert die Datenbanktabelle für Kunden.
# from .models import Client


# #class ClientViewSet(viewsets.ModelViewSet):: Definiert eine neue Klasse namens ClientViewSet, die die ModelViewSet-Klasse
# # von Django REST Framework erweitert. Dadurch erhält die Klasse vordefinierte Methoden und Verhaltensweisen für die CRUD-Operationen.
# class ClientViewSet(viewsets.ModelViewSet):
#     serializer_class = ClientSerializer #serializer_class = ClientSerializer: Legt die Serializer-Klasse ClientSerializer als serializer_class für das ClientViewSet fest. Dies bestimmt, wie die Daten des Client-Modells serialisiert und deserialisiert werden.
#     queryset = Client.objects.all() #queryset = Client.objects.all(): Legt die Abfrage (QuerySet) für das ClientViewSet fest. In diesem Fall wird das gesamte Client-Objekte-Set aus der Datenbank abgerufen.


# #def get_queryset(self):: Definiert eine Methode get_queryset, die das Standard-QuerySet für das ViewSet überschreibt.
#     def get_queryset(self):

#         # return self.queryset.filter(created_by=self.request.user): Gibt das gefilterte QuerySet zurück, das nur 
#         # Client-Objekte enthält, die vom aktuellen Benutzer erstellt wurden. Das created_by-Feld des Client-Modells wird mit dem aktuellen Benutzer (aus self.request.user) verglichen.
#         return self.queryset.filter(created_by=self.request.user),





# #Der ClientViewSet ermöglicht es, API-Endpunkte für das Client-Modell zu erstellen, die die CRUD-Operationen unterstützen.
# # Die Serializer-Klasse wird verwendet, um die Daten zwischen dem Modell und JSON (oder anderen Datenformaten) zu konvertieren.
# # Das QuerySet wird verwendet, um die Datenbankabfrage für die einzelnen Operationen zu steuern, und die get_queryset-Methode
# # ermöglicht es, das QuerySet basierend auf benutzerspezifischen Filtern zu ändern.

from django.shortcuts import render

from rest_framework import viewsets 

from .serializers import ClientSerializer
from .models import Client

from django.core.exceptions import PermissionDenied


#ClientViewSet is a class that represents a view set for the Client model.
class ClientViewSet(viewsets.ModelViewSet):

    # serializer_class is set to ClientSerializer, which specifies the serializer used for serializing
    # and deserializing Client instances. The serializer determines how the data is represented when sent
    # over the network and how it is converted back to Python objects.
    serializer_class = ClientSerializer

    #queryset is set to Client.objects.all(), which retrieves all the Client objects from the database.
    # It represents the initial query set of objects that the view will operate on.
    queryset = Client.objects.all()

    #get_queryset is a method that filters the queryset based on the current user. It returns a queryset
    # that contains only the Client objects created by the current user making the request. This is achieved
    # by filtering the queryset using the created_by field, which is compared to self.request.user, representing the authenticated user.
    def get_queryset(self):
        return self.queryset.filter(created_by=self.request.user)
    
    #perform_create is a method that is called during the creation of a new Client object. It sets the created_by field
    # of the serializer to the current user making the request. This ensures that the created_by field is populated correctly
    # when a new Client object is created.

    def perform_create(self, serializer):
        serializer.save(created_by=self.request.user)

    # perform_update is a method that is called during the update of an existing Client object. It first retrieves the object being updated using self.get_object().
    
    def perform_update(self, serializer):
        obj = self.get_object()

    #It then checks if the current user is the owner of the object by comparing self.request.user with the created_by field of the object (obj). If they are not the same,
    # it raises a PermissionDenied exception, indicating that the user does not have permission to update the object.
        if self.request.user != obj.created_by:
            raise PermissionDenied('Wrong object owner')
        

        #If the user is the owner, the serializer's save method is called to update the object with the data provided in the request.
        serializer.save()