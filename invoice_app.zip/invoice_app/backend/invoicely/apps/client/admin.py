from django.contrib import admin

from .models import Client

admin.site.register(Client) #regestrieren damit man es auf der admin seite sieht
