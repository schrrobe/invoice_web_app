from rest_framework import serializers

from .models import Invoice, Item

class ItemSerializer(serializers.ModelSerializer):   
    class Meta:
        model = Item
        read_only_fields = (
            "invoice",
        )
        fields = (
            "id",
            "title",
            "quantity",
            "unit_price",
            "net_amount",
            "vat_rate",
            "discount"
        )

class InvoiceSerializer(serializers.ModelSerializer): 
    items = ItemSerializer(many=True)
    bankaccount = serializers.CharField(required=False)

    class Meta:
        model = Invoice
        read_only_fields = (
            "team",
            "invoice_number",
            "created_at",
            "created_by",
            "modified_at",
            "modified_by",
        ),
        fields = (
            "id",
            "invoice_number",
            "client",
            "client_name",
            "client_email",
            "client_org_number",
            "client_address1",
            "client_address2",
            "client_zipcode",
            "client_place",
            "client_country",
            "client_contact_person",
            "client_contact_reference",
            "sender_reference",
            "invoice_type",
            "due_days",
            "is_sent",
            "is_paid",
            "gross_amount",
            "vat_amount",
            "net_amount",
            "discount_amount",
            "items",
            "bankaccount",
            "get_due_date_formatted",
            "is_credit_for",
            "is_credited",
        )
    def create(self, validated_data):
        items_data = validated_data.pop('items')
        invoice = Invoice.objects.create(**validated_data)

        for item in items_data:
            Item.objects.create(invoice=invoice, **item)
        
        return invoice

# Dieser Code definiert eine Methode namens "create" in einer Klasse. Die Methode erwartet ein Argument namens "validated_data". 
# Hier ist eine Erläuterung des Codes:

# 1. Die Methode nimmt das Attribut "items" aus dem übergebenen "validated_data" heraus und speichert es in der Variablen "items_data".
# Das bedeutet, dass die "validated_data" ein Dictionary ist und ein Schlüssel namens "items" enthält.

# 2. Es wird eine neue Instanz des Modells "Invoice" erstellt und mit den restlichen Elementen aus dem "validated_data" initialisiert.
# Das Sternchen vor "validated_data" entpackt das Dictionary und verwendet die Schlüssel-Wert-Paare als Argumente für die Erstellung der Instanz.

# 3. Eine Schleife wird durch jedes Element in "items_data" durchlaufen. Für jedes Element wird eine neue Instanz des Modells "Item"
# erstellt und mit dem erstellten "invoice"-Objekt sowie den restlichen Elementen aus dem aktuellen Element in "items_data" initialisiert.

# 4. Schließlich wird das "invoice"-Objekt zurückgegeben, das bedeutet, dass diese Methode ein erstelltes "invoice"-Objekt zurückgibt.

# Zusammenfassend nimmt die Methode "create" eine Liste von Elementen ("items_data") entgegen, erstellt eine Instanz des Modells "Invoice"
# mit den gegebenen Daten und erstellt dann für jedes Element in "items_data" eine Instanz des Modells "Item", die mit dem "invoice"-Objekt
# verknüpft ist. Schließlich wird das "invoice"-Objekt zurückgegeben.