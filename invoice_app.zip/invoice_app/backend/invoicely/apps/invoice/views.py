from rest_framework import viewsets

import pdfkit
from pdfkit.configuration import Configuration

from django.core.exceptions import PermissionDenied
from django.core.mail import EmailMultiAlternatives
from django.http import HttpResponse
from django.shortcuts import get_object_or_404
from django.template.loader import get_template

from rest_framework import viewsets
from rest_framework import status, authentication, permissions
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.response import Response

from .serializers import InvoiceSerializer, ItemSerializer
from .models import Invoice, Item

from apps.team.models import Team

class InvoiceViewSet(viewsets.ModelViewSet):
    serializer_class = InvoiceSerializer
    queryset = Invoice.objects.all()

    def get_queryset(self):
        return self.queryset.filter(created_by= self.request.user)
    
    def perform_create(self, serializer):
        team = self.request.user.teams.first()
        invoice_number = team.first_invoice_number
        team.first_invoice_number = invoice_number + 1
        team.save()
        serializer.save(created_by=self.request.user, team = team, modified_by = self.request.user, invoice_number=invoice_number, bankaccount=team.bankaccount)

    def perform_update(self, serializer):
        obj = self.get_object()

        if self.request.user != obj.created_by:
            raise PermissionDenied('Wrong object owner')
        
        serializer.save()


# Dieser Code definiert eine Ansicht (View) für die Behandlung von RESTful-Anfragen im Zusammenhang mit Rechnungen (Invoices) in 
# einer Webanwendung, die das Django REST Framework verwendet. Hier ist eine Erklärung des Codes:

# 1. `from rest_framework import viewsets`: Importiert die `viewsets`-Klasse aus dem Django REST Framework, die zur Erstellung 
# von Ansichten für RESTful-Ressourcen verwendet wird.

# 2. `from .serializers import InvoiceSerializer`: Importiert den Serializer `InvoiceSerializer`, der verwendet wird, um Rechnungsdaten 
# in das JSON-Format zu serialisieren und umgekehrt.

# 3. `from .models import Invoice, Item`: Importiert die Modelle `Invoice` und `Item`, die die Datenbanktabellen für Rechnungen und Rechnungsposten 
# repräsentieren.

# 4. `from django.core.exceptions import PermissionDenied`: Importiert die Ausnahme `PermissionDenied` aus dem Django-Framework, die verwendet wird, 
# um eine Berechtigungsverweigerung anzuzeigen.

# 5. `class InvoiceViewSet(viewsets.ModelViewSet):`: Definiert eine Klasse `InvoiceViewSet`, die von der `ModelViewSet`-Klasse des Django REST 
# Frameworks erbt. Dadurch werden alle grundlegenden CRUD-Operationen (Create, Retrieve, Update, Delete) für das Modell `Invoice` automatisch bereitgestellt.

# 6. `serializer_class = InvoiceSerializer`: Legt den Serializer `InvoiceSerializer` als Serializer-Klasse für die Ansicht fest. Der Serializer 
# wird verwendet, um Daten zwischen Python-Objekten und JSON zu konvertieren.

# 7. `queryset = Invoice.objects.all()`: Legt die Abfrage (Queryset) für die Ansicht fest. Hier wird der Queryset auf alle Rechnungen in der 
# Datenbank gesetzt.

# 8. `def get_queryset(self):`: Definiert eine Methode `get_queryset`, die den Queryset für die Ansicht anpasst. In diesem Fall wird der Queryset auf 
# Rechnungen des aktuellen Benutzers (self.request.user) eingeschränkt.

# 9. `def perform_create(self, serializer):`: Definiert eine Methode `perform_create`, die aufgerufen wird, wenn eine neue Rechnung erstellt wird. 
# Diese Methode fügt der erstellten Rechnung den Ersteller (self.request.user) und das zugehörige Team hinzu.

# 10. `def perform_update(self, serializer):`: Definiert eine Methode `perform_update`, die aufgerufen wird, wenn eine Rechnung aktualisiert wird. 
# Diese Methode überprüft, ob der aktuelle Benutzer der Ersteller der Rechnung ist. Wenn nicht, wird eine Berechtigungsverweigerung (PermissionDenied) ausgelöst.

# Der Code stellt also eine RESTful API zur Verfügung, um Rechnungsdaten zu erstellen, abzurufen, zu aktualisieren und zu löschen. Die Ansicht ist auf d
# en aktuellen Benutzer beschränkt und stellt sicher, dass nur der Ersteller einer Rechnung diese aktualisieren kann.


@api_view(['GET'])
@authentication_classes([authentication.TokenAuthentication])
@permission_classes([permissions.IsAuthenticated])


def generate_pdf(request, invoice_id):
    invoice = get_object_or_404(Invoice, pk=invoice_id, created_by=request.user)
    team = Team.objects.filter(created_by=request.user).first()
    template_name ='pdf.html'

    if invoice.is_credit_for:
        template_name='pdf_creditnote.html'

    template = get_template(template_name)
    html = template.render({'invoice': invoice, 'team': team})

    # Specify the path to the wkhtmltopdf executable
    path_to_wkhtmltopdf = 'C:/Program Files/wkhtmltopdf/bin/wkhtmltopdf.exe'

    # Configure pdfkit to use the specified executable path
    config = Configuration(wkhtmltopdf=path_to_wkhtmltopdf)

    pdf = pdfkit.from_string(html, False, options={}, configuration=config)

    response = HttpResponse(pdf, content_type='application/pdf')
    response['Content-Disposition'] = 'attachment; filename="invoice.pdf"'

    return response


@api_view(['GET'])
@authentication_classes([authentication.TokenAuthentication])
@permission_classes([permissions.IsAuthenticated])
def send_reminder(request, invoice_id):
    invoice = get_object_or_404(Invoice, pk=invoice_id, created_by=request.user)
    team = Team.objects.filter(created_by=request.user).first()

    subject = 'Unpaid invoice'
    from_email = team.email
    to = [invoice.client.email]
    text_content = 'You have an unpaid invoice. Invoice number: #' + str(invoice.invoice_number)
    html_content = 'You have an unpaid invoice. Invoice number: #' + str(invoice.invoice_number)

    msg = EmailMultiAlternatives(subject, text_content, from_email, to)
    msg.attach_alternative(html_content, "text/html")

    template = get_template('pdf.html')
    html = template.render({'invoice': invoice, 'team': team})
    # Specify the path to the wkhtmltopdf executable
    path_to_wkhtmltopdf = 'C:/Program Files/wkhtmltopdf/bin/wkhtmltopdf.exe'

    # Configure pdfkit to use the specified executable path
    config = Configuration(wkhtmltopdf=path_to_wkhtmltopdf)

    pdf = pdfkit.from_string(html, False, options={}, configuration=config)

    if pdf:
        name = 'invoice_%s.pdf' % invoice.invoice_number
        msg.attach(name, pdf, 'application/pdf')

    msg.send()

    return Response()

     
   
    
   


        