
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    path('api/v1/', include('djoser.urls')),
    path('api/v1/', include('djoser.urls.authtoken')),
    path('api/v1/', include('apps.client.urls')),
    path('api/v1/', include('apps.team.urls')),
    path('api/v1/', include('apps.invoice.urls'))
]


# Die urlpatterns-Liste in der urls.py-Datei von Django definiert die Zuordnung zwischen URL-Mustern und den entsprechenden 
# Views oder Ressourcen in deinem Django-Projekt. Lass uns das von dir bereitgestellte Beispiel erklären:

# path('admin/', admin.site.urls): Diese Zeile ordnet das URL-Muster "admin/" der Django-Admin-Seite zu.
#  Wenn ein Benutzer "/admin/" besucht, wird Django die Admin-Oberfläche anzeigen.

# path('api/v1/', include('djoser.urls')): Diese Zeile ordnet das URL-Muster "api/v1/" den URLs zu, die in dem Modul
#   'djoser.urls' definiert sind. Djoser ist ein Django-Paket, das eine Reihe von Views und Endpunkten für die Benutzerauthentifizierung
#  und -registrierung bereitstellt. Durch das Einbinden von 'djoser.urls' ermöglichst du den Zugriff auf diese Endpunkte unter dem URL-Präfix "api/v1/".

#path('api/v1/', include('djoser.urls.authtoken')): Diese Zeile ordnet das URL-Muster "api/v1/" den URLs zu,
#  die in dem Modul 'djoser.urls.authtoken' definiert sind. Dieses Modul bietet zusätzliche Endpunkte für
#  tokenbasierte Authentifizierung mit Djoser. Durch das Einbinden von 'djoser.urls.authtoken' ermöglichst
#  du den Zugriff auf diese Authentifizierungs-Endpunkte unter dem URL-Präfix "api/v1/".

# Zusammenfassend definiert die urlpatterns-Liste drei URL-Muster: die Admin-Seite, die Djoser-Endpunkte für die allgemeine
#  Benutzerverwaltung (djoser.urls) und die Djoser-Endpunkte für die tokenbasierte Authentifizierung (djoser.urls.authtoken).
#  Diese Muster bestimmen die URLs, die Benutzer besuchen können, um auf verschiedene Teile deiner Django-Anwendung zuzugreifen,
#  wie z.B. die Admin-Oberfläche oder die API-Endpunkte, die von Djoser bereitgestellt werden.