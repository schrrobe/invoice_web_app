import { createRouter, createWebHistory } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import dashboardView from "@/views/Dashboard/DashboardView.vue";
import signUpView from "@/views/SignUpView.vue";
import loginView from "@/views/LoginView.vue";
import store from "@/store";
import myAccountView from "@/views/Dashboard/MyAccountView.vue";
import clientsView from "@/views/Dashboard/ClientsView.vue";
import clientView from "@/views/Dashboard/ClientView.vue";
import addClientView from "@/views/Dashboard/AddClientView.vue";
import editClientView from "@/views/Dashboard/EditClientView.vue";
import editTeamView from "@/views/Dashboard/EditTeamView.vue";
import invoicesView from "@/views/Dashboard/InvoicesView.vue";
import invoiceView from "@/views/Dashboard/InvoiceView.vue";
import addInvoiceView from "@/views/Dashboard/AddInvoiceView.vue";

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView
  },
  {
    path: '/dashboard',
    name: 'dashboard',
    component: dashboardView,
    meta: {
      requiresLogin: true,
    }
  },
  {
    path: '/dashboard/my-account',
    name: 'my-account',
    component: myAccountView,
    meta: {
      requiresLogin: true,
    },
},
  {
    path: '/dashboard/clients/',
    name: 'clients',
    component: clientsView,
    meta: {
      requiresLogin: true,
    },
  },
  {
    path: '/dashboard/clients/:id', // :id is a dynamic segment
    name: 'client',
    component: clientView,
    meta: {
      requiresLogin: true,
    },
  },
  {
    path: '/dashboard/clients/add',
    name: 'addClient',
    component: addClientView,
    meta: {
      requiresLogin: true,
    },
  },
  {
    path: '/dashboard/clients/:id/edit',
    name: 'editClient',
    component: editClientView,
    meta: {
      requiresLogin: true,
    },
  },
  {
    path: '/dashboard/my-account/edit-team',
    name: 'editTeam',
    component: editTeamView,
    meta: {
      requiresLogin: true,
    },
  },
  {
    path: '/dashboard/invoices',
    name: 'invoicesView',
    component: invoicesView,
    meta: {
      requiresLogin: true,
    },
  },
  {
    path: '/dashboard/invoices/:id',
    name: 'invoiceView',
    component: invoiceView,
    meta: {
      requiresLogin: true,
    },
  },
  {
    path: '/dashboard/invoices/add',
    name: 'addInvoice',
    component: addInvoiceView,
    meta: {
      requiresLogin: true,
    },
  },
  {
    path: '/sign-up',
    name: 'sign-up',
    component: signUpView
  },
  {
    path: '/login',
    name: 'login',
    component: loginView
  },
  {
    path: '/about',
    name: 'about',
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () => import(/* webpackChunkName: "about" */ '../views/AboutView.vue')
  }
]

const router = createRouter({
  history: createWebHistory(process.env.BASE_URL),
  routes
})
router.beforeEach((to, from, next) => {
  if(to.matched.some(record => record.meta.requiresLogin) && !store.state.isAuthenticated) {
    next('/login')
  }else {
   next()
  }
},)
// Der oben gegebene Code definiert eine Navigationsschutzlogik in einer Vue.js-Anwendung. Es handelt sich um eine
// Router-Guards-Funktion, die vor jedem Navigationsvorgang ausgeführt wird, bevor eine neue Route geladen wird.
//
// Die Funktion überprüft, ob die zu navigierende Route mit der Meta-Eigenschaft "requiresLogin" markiert ist
// und ob der Zustand "isAuthenticated" im Store nicht wahr ist. Wenn beide Bedingungen erfüllt sind, wird der
//Benutzer zur Login-Seite weitergeleitet. Andernfalls wird der Benutzer zur nächsten Route weitergeleitet.
//
// Der Code stellt sicher, dass nur authentifizierte Benutzer auf bestimmte geschützte Bereiche der Anwendung
// zugreifen können. Wenn ein Benutzer nicht eingeloggt ist und versucht, auf eine Seite zuzugreifen, die eine
// Authentifizierung erfordert, wird er automatisch zur Login-Seite umgeleitet.
//
//Es ist anzumerken, dass dieser Codeauszug Teil eines größeren Vue.js-Projekts ist, da er auf einen Store (vermutlich Vuex)
// und eine Router-Konfiguration verweist.
export default router
