import { createStore } from 'vuex'

export default createStore({
  // state: Dieser Teil definiert den anfänglichen Zustand des Stores. Hier wird ein user-Objekt mit einer
  // username-Eigenschaft, ein isAuthenticated-Flag und ein token für die Authentifizierung gespeichert.
  state: {
    user: {
      id: '',
      username:'',
    },
    isAuthenticated: false,
    token: '',
  },
  // getters: In diesem Abschnitt können Getter definiert werden, die den Zustand des Stores abrufen.
  // In deinem Code sind keine Getter definiert.
  getters: {
  },
  // mutations: Hier werden Mutationen definiert, die den Zustand im Store ändern dürfen.
  mutations: {
    // initialiseStore: Diese Mutation wird aufgerufen, um den Zustand des Stores zu initialisieren.
    // Sie überprüft, ob ein Token im Local Storage vorhanden ist und aktualisiert den Zustand entsprechend.
    initialiseStore(state){
      if(localStorage.getItem('token')){
        state.token = localStorage.getItem('token')
        state.isAuthenticated = true
        state.user.username = localStorage.getItem('username')
        state.user.id = localStorage.getItem('userid')
      }else{
        state.token = ''
        state.user.id= ''
        state.user.username= ''
        state.isAuthenticated = false
      }
    },
    // setToken: Diese Mutation wird aufgerufen, um den Token im Zustand zu setzen und isAuthenticated auf true zu setzen.
    setToken(state, token){
      state.token = token
      state.isAuthenticated = true
    },
    // removeToken: Diese Mutation wird aufgerufen, um den Token aus dem Zustand zu entfernen und isAuthenticated
    // auf false zu setzen.
    removeToken(state){
      state.user.id= ''
      state.user.username= ''
      state.token = ''
      state.isAuthenticated = false
    },
    setUser(state, user){
        state.user.id = user
    }
  },
  // actions: Hier können asynchrone Aktionen definiert werden, die Mutationen auslösen oder andere logische Operationen
  // durchführen können. In deinem Code sind keine Aktionen definiert.
  actions: {
  },
  modules: {
  }
})
