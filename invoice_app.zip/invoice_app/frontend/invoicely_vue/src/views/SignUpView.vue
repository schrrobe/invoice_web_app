<template>
    <div class="page-sign-up">
        <div class="columns">
            <div class="column is-4 is-offset-4">
                <h1 class="title">Sign Up</h1>

                <form @submit.prevent="submitForm">
                    <div class="field">
                        <label class="label">Username</label>
                        <div class="control">
                            <input class="input" type="text" placeholder="Username" v-model="username">
                        </div>
                    </div>
                    <div class="field">
                        <label class="label">Password</label>
                        <div class="control">
                            <input class="input" type="password" placeholder="Password" v-model="password">
                        </div>
                    </div>
                    <div class="notification is-danger" v-if="errors.length">
                        <p v-for="error in errors" :key="error">{{ error }}</p>
                    </div>
                    <div class="field">
                        <div class="control">
                            <button class="button is-success" type="submit">Sign up</button>
                        </div>
                    </div>
                </form>
                <hr>
                <router-link to="/sign-up">Click here </router-link> to Log in.
            </div>
        </div>
    </div>
</template>

<script>
import axios from "axios";

export default {
    name: "SignUpView",
    data() {
        return {
            username: "",
            password: "",
            errors: []
        };
    },
    methods: {
        //eslint-disable-next-line no-unused-vars
        submitForm(e) { // e is the event object of the form very important
            const formData = {
                username: this.username,
                password: this.password
            };
            axios.post("/api/v1/users/", formData)
                .then(response => {
                    console.log(response);
                    this.$store.commit("setToken", response.data.token);
                    this.$store.commit("setUsername", response.data.username);
                    this.$router.push("/dashboard");
                })
                .catch(error => {
                    if(error.response) {
                        for (const property in error.response.data) {
                            this.errors.push(`${property}: ${error.response.data[property]}`)
                        }
                        console.log(JSON.stringify(error.response.data));
                    }else if(error.message) {
                        console.log(error.message);
                    } else {
                        console.log(JSON.stringify(error));
                    }
            })
        }
    }
}
</script>

<style scoped>

</style>
