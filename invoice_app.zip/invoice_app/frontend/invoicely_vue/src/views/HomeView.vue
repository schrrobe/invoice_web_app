<template>
  <div>
  <div class="home">
    <h1 class="title">Welcome to Invoicely</h1>
  </div>
  <div class="time-box">
    <p class="time"><strong>3:56:00</strong></p>
  </div>
</div>
</template>

<script>
// @ is an alias to /src

export default {
  name: 'HomeView',
  components: {
  }
}
</script>
<style lang="css" scoped>
.home {
  display: flex
}
.title {
  margin: auto;
}
.time-box {
  display: flex
}
.time {
  margin: auto;
  color: brown;
}
</style>
