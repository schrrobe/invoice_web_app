<template>
<div class="page-my-account">
    <nav class="breadcrumb" aria-label="breadcrumbs">
        <ul>
            <li>
                <router-link to="/dashboard">Dashboard</router-link>
            </li>
            <li class="is-active">
                <router-link to="/dashboard/my-account" aria-current="true">
                My Account
                </router-link>
            </li>
        </ul>
    </nav>
    <h1 class="title">My Account</h1>
    <strong>Team: </strong> {{team.name}} <br>
    <strong>Username: </strong> {{ $store.state.user.username }} <br>
    <hr>
    <div class="buttons">
        <router-link to="/dashboard/my-account/edit-team" class="button is-light">Edit Team</router-link>
        <button @click="logout()" class="button is-danger">Log out</button>
    </div>
</div>
</template>

<script>
import axios from "axios";
export default {
    name: "MyAccountView",
    data() {
        return {
            username: "",
            password: "",
            errors: [],
            team: {}
        };
    },
    async mounted() {
        await this.getTeam();
    },
    methods: {
        logout() {
            axios
                .post("/api/v1/token/logout/")
                .then(response => {
                    axios.defaults.headers.common["Authorization"] = ""

                    localStorage.removeItem("username")
                    localStorage.removeItem("userid")
                    localStorage.removeItem("token")

                    this.$store.commit('removeToken')

                    this.$router.push('/')
                })
                .catch(error => {
                    if (error.response) {
                        console.log(JSON.stringify(error.response.data))
                    } else if (error.message) {
                        console.log(JSON.stringify(error.message))
                    } else {
                        console.log(JSON.stringify(error))
                    }
                })
        },
        getTeam() {

            axios.get('/api/v1/teams/')
                .then(response => {
                    this.team = response.data[0];
                }).catch(error => {
                console.log(JSON.stringify(error));
            })
        },
    }
}
</script>

<style scoped>

</style>
