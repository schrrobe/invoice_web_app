<template>
    <div class="page-clients">
        <nav class="breadcrumb" aria-label="breadcrumbs">
            <ul>
                <li>
                    <router-link to="/dashboard">Dashboard</router-link>
                </li>
                <li>
                    <router-link to="/dashboard/invoices">Invoices</router-link>
                </li>
                <li class="is-active">
                    <router-link :to="{name: 'client', params: { id: invoice.id }}" aria-current="true">
                    {{ invoice.invoice_number }}
                    </router-link>
                </li>
            </ul>
    
        </nav>
        <div class="columns is-multiline">
            <div class="column is-12">
                <h1 class="title"> Invoice - {{ invoice.invoice_number }}</h1>
            </div>
            <hr>
            <div class="buttons">
                <button @click="getPdf()" class="button is-dark">Download PDF </button>
                <template v-if="!invoice.is_credit_for && !invoice.is_credited">
                    <button @click="setAsPaid()" class="button is-success" v-if="!invoice.is_paid">Set as paid </button>
                    <button @click="createCreditNote()" class="button is-danger" v-if="!invoice.is_credit_for">Create Creditnote </button>
                </template>
                <button @click="sendReminder()" class="button is-info" v-if="!invoice.is_paid">Send Reminder </button>
            </div>
        
            <div class="column is-12 mb-4">
                <div class="box">
                    <h3 class="is-size-4 mb-5">Client</h3>

                    <p><strong>{{ invoice.client_name }}</strong></p>

                    <p v-if="invoice.client_address1">{{ invoice.client_address1 }}</p>
                    <p v-if="invoice.client_address2">{{ invoice.client_address2 }}</p>
                    <p v-if="invoice.client_zipcode || invoice.client_place">{{ invoice.client_zipcode }} {{ invoice.client_place }}</p>
                    <p v-if="invoice.client_country">{{ invoice.client_country }}</p>
                </div>
            </div>

            <div class="column is-12">
                <div class="box">
                    <table class="table is-fullwidth">
                        <thead>
                        <tr>
                            <th>Title</th>
                            <th>Quantity</th>
                            <th>Amount</th>
                        </tr>
                        </thead>
                    <tbody>
                        <tr
                            class="item"
                            v-for="item in invoice.items"
                            v-bind:key="item.id">
                            <td>{{ item.title }}</td>
                            <td>{{ item.quantity }}</td>
                            <td>{{ item.net_amount }}</td>
                        </tr>
                    </tbody>
                    </table>
                </div>
            </div>

            <div class="column is-12">
                <div class="box">
                    <div class="columns">
                        <div class="column is-5">
                            <p><strong>Net amount:</strong>{{ invoice.net_amount }}</p>
                            <p><strong>Vat amount:</strong>{{ invoice.vat_amount }}</p>
                            <p><strong>Gross amount:</strong>{{ invoice.gross_amount }}</p>
                            <p><strong>Bank account:</strong>{{ invoice.bankaccount }}</p>
        
                        </div>
                        <div class="column is-5">
                            <p><strong>Our reference:</strong>{{ invoice.sender_reference }}</p>
                            <p><strong>Client reference:</strong>{{ invoice.client_contact_reference }}</p>
                            <p><strong>Due date:</strong>{{ invoice.get_due_date_formatted }}</p>
                            <p><strong>Status:</strong>{{ getStatusLabel() }}</p>
                            <p><strong>Invoice type:</strong>{{ getInvoiceType() }}</p>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>

</template>

<script>
import axios from "axios";
import { toast } from 'bulma-toast'
const fileDownload = require('js-file-download');

export default {
    name: "invoiceView",
    data() {
        return {
            invoice: {},
        }
    },
    mounted() {
        this.getInvoice();
    },
    methods: {
        getInvoice(){
            const invoiceId = this.$route.params.id;
            axios
                .get(`/api/v1/invoices/${invoiceId}`)
                .then(response => {
                    this.invoice = response.data;

                })
                .catch((error) => {
                    console.log(JSON.stringify(error));
                })
        },
        getPdf() {
            const invoiceId = this.$route.params.id;
            axios
                .get(`/api/v1/invoices/${invoiceId}/generate_pdf`, {responseType: 'blob'})
                .then(res => {
                    fileDownload(res.data,`invoice_${invoiceId}.pdf`);
                }).catch(err => {
                    console.log(err);
            })
        },
        getStatusLabel() {
            if(this.invoice.is_paid) {
                return ' is paid';
            }else {
                return ' is not paid';
            }
        },
        getInvoiceType() {
            if(this.invoice.invoice_type === 'invoice') {
                return ' Invoice';
            }else {
                return ' Credit note';
            }
        },
        async setAsPaid() {
            this.invoice.is_paid = true;

            let items = this.invoice.items

            delete this.invoice['items']

            await axios.patch(`/api/v1/invoices/${this.invoice.id}/`, this.invoice)
            .then(response => {
                toast({
                    message: 'The changes was saved',
                    type: 'is-success',
                    dismissible: true,
                    pauseOnHover: true,
                    duration: 2000,
                    position: 'bottom-right',
                })
            })
            .catch(error => {
                console.log(JSON.stringify(error))
            })
            this.invoice.items = items
        },
        async createCreditNote() {
                this.invoice.is_credited = true

                let items = this.invoice.items

                delete this.invoice['items']

                await axios
                    .patch(`/api/v1/invoices/${this.invoice.id}/`, this.invoice)
                    .then(response => {
                        toast({
                            message: 'The changes was saved',
                            type: 'is-success',
                            dismissible: true,
                            pauseOnHover: true,
                            duration: 2000,
                            position: 'bottom-right',
                        })
                    })
                    .catch(error => {
                        console.log(JSON.stringify(error))
                    })
                
                this.invoice.items = items
                
                let creditNote = this.invoice
                creditNote.is_credit_for = this.invoice.id
                creditNote.is_credited = false
                creditNote.invoice_type = 'credit_note'

                delete creditNote['id']

                await axios
                    .post('api/v1/invoices/', creditNote)
                    .then(response => {
                        toast({
                            message: 'The credit note was created',
                            type: 'is-success',
                            dismissible: true,
                            pauseOnHover: true,
                            duration: 2000,
                            position: 'bottom-right',
                        })

                        this.$router.push('/dashboard/invoices')
                    })
                    .catch(error => {
                        console.log(JSON.stringify(error))
                    })
            },
            sendReminder() {
                axios
                    .get(`api/v1/invoices/${this.invoice.id}/send_reminder/`)
                    .then(response => {
                        toast({
                            message: 'The Reminder was send',
                            type: 'is-success',
                            dismissible: true,
                            pauseOnHover: true,
                            duration: 2000,
                            position: 'bottom-right',
                        })
                    })
                    .catch(error => {
                        console.log(JSON.stringify(error))
                    })

            }
    }

}
</script>

<style scoped>

</style>
