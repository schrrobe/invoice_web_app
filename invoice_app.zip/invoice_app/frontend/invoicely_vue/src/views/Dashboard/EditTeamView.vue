<template>
<div class="page-edit-team">
    
    <div class="column is-multiline">
        <nav class="breadcrumb" aria-label="breadcrumbs">
            <ul>
                <li>
                    <router-link to="/dashboard">Dashboard</router-link>
                </li>
                <li>
                    <router-link to="/dashboard/my-account">My Account</router-link>
                </li>
                <li class="is-active">
                    <router-link to="/dashboard/my-account/edit-team" aria-current="true">
                    Edit team
                    </router-link>
                </li>
            </ul>
        </nav>
        <div class="column is-12">
            <h1 class="title">Edit Team</h1>
            <div class="column is-12">
                <div class="field">
                    <label class="label">Name</label>
                    <div class="control">
                        <input class="input" type="text" placeholder="Name" name="name" v-model="team.name">
                    </div>
                </div>

                <div class="field">
                    <label class="label">Org. Number</label>
                    <div class="control">
                        <input class="input" type="text" name="org-number" v-model="team.org_number">
                    </div>
                </div>

                <div class="field">
                    <label class="label">First invoice number</label>
                    <div class="control">
                        <input type="number" class="input" v-model="team.first_invoice_number">
                    </div>
                </div>

                <div class="field">
                    <label class="label">Bankaccount</label>
                    <div class="control">
                        <input type="tect" class="input" v-model="team.bankaccount">
                    </div>
                </div>
                
                <div class="field">
                    <label class="label">Email</label>
                    <div class="control">
                        <input type="tect" class="input" v-model="team.email">
                    </div>
                </div>

                <div class="field">
                    <label class="label">Address1</label>
                    <div class="control">
                        <input type="tect" class="input" v-model="team.adress1">
                    </div>
                </div>

                <div class="field">
                    <label class="label">Address2 </label>
                    <div class="control">
                        <input type="tect" class="input" v-model="team.adress2">
                    </div>
                </div>

                <div class="field">
                    <label class="label">Zipcode </label>
                    <div class="control">
                        <input type="tect" class="input" v-model="team.zipcode">
                    </div>
                </div>
                <div class="field">
                    <label class="label">Place</label>
                    <div class="control">
                        <input type="tect" class="input" v-model="team.place">
                    </div>
                </div>

                <div class="field">
                    <div class="control">
                        <button class="button is-success" @click="submitForm">Save</button>
                    </div>
                </div>
            </div>

    </div>
</div>
</div>
</template>

<script>
import axios from "axios";
export default {
    name: "EditTeamView",
    data() {
        return {
            team: {},
        }
    },
    async mounted() {
        await this.getOrCreateTeam();
    },
    methods: {
        async getOrCreateTeam() {

            axios.get('/api/v1/teams/')
                .then(response => {
                    this.team = response.data[0];
                }).catch(error => {
                    console.log(JSON.stringify(error));
                })
        },

        submitForm() {
            axios.patch(`/api/v1/teams/${this.team.id}/`, this.team)
                /* eslint-disable no-unused-vars */
                .then(response => {
                    this.$router.push('/dashboard/my-account');
                }).catch(error => {
                    console.log(JSON.stringify(error));
                })

        }
    }
}
</script>

<style scoped>
.page-edit-team {
    margin: auto;
    padding: 0 150px;
}
</style>
