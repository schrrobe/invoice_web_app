<template>
    <div class="page-add-client">
        <nav class="breadcrumb" aria-label="breadcrumbs">
            <ul>
                <li>
                    <router-link to="/dashboard">Dashboard</router-link>
                </li>
                <li>
                    <router-link to="/dashboard/clients" aria-current="true">
                    Clients
                    </router-link>
                </li>
                <li>
                    <router-link :to="{name: 'client', params: {id: client.id}}" aria-current="true">
                    {{ client.name }}
                    </router-link>
                </li>
                <li class="is-active">
                    <router-link :to="{name: 'editClient', params: {id: client.id}}" aria-current="true">
                    edit {{ client.name }}
                    </router-link>
                </li>
            </ul>
    
        </nav>
        <div class="columns is-multiline">
            <div class="column is-12">
                <h1 class="title">Edit Client - {{ client.name}}</h1>

            </div>

            <div class="column is-6">
                <div class="field">
                    <label class="label">Name</label>
                    <div class="control">
                        <input class="input" type="text" placeholder="Name" name="name" v-model="client.name">
                    </div>
                </div>
            </div>

            <div class="column is-6">
                <div class="field">
                    <label class="label">E-mail</label>
                    <div class="control">
                        <input class="input" type="text" placeholder="Name" name="email" v-model="client.email">
                    </div>
                </div>
            </div>

            <div class="column is-6">
                <div class="field">
                    <label class="label">Address 1</label>
                    <div class="control">
                        <input class="input" type="text" name="address1" v-model="client.address1">
                    </div>
                </div>
            </div>
            <div class="column is-6">
                <div class="field">
                    <label class="label">Address 2</label>
                    <div class="control">
                        <input class="input" type="text" name="address2" v-model="client.address2">
                    </div>
                </div>
            </div>
            <div class="column is-6">
                <div class="field">
                    <label class="label">ZipCode</label>
                    <div class="control">
                        <input class="input" type="text" name="zipcode" v-model="client.zipcode">
                    </div>
                </div>
            </div>
            <div class="column is-6">
                <div class="field">
                    <label class="label">Client place</label>
                    <div class="control">
                        <input class="input" type="text" name="zipcode" v-model="client.place">
                    </div>
                </div>
            </div>
            <div class="column is-6">
                <div class="field">
                    <label class="label">Country</label>
                    <div class="control">
                        <input class="input" type="text" name="zipcode" v-model="client.country">
                    </div>
                </div>
            </div>
            <div class="column is-12"></div>
            <div class="column is-6">
                <div class="field">
                    <label class="label">Contact Person</label>
                    <div class="control">
                        <input class="input" type="text" name="contact_person" v-model="client.contactPerson">
                    </div>
                </div>
            </div>
            <div class="column is-12">
                <div class="field">
                    <div class="control">
                        <button class="button is-success" @click="submitForm">Save Changes</button>
                    </div>
                </div>
            </div>

        </div>
    </div>
</template>

<script>
import axios from "axios";
export default {
    name: "EditClientView",
    data() {
        return {
            client: {
                name: "",
                address1: "",
                address2: "",
                zipcode: "",
                place: "",
                country: "",
                contactPerson: "",
                contact_reference: "",
                created_by: "",
                created_at: "",
                contactReference: "",
            },
            errors: []
        }
    },
    mounted() {
        this.getClient();
    },
    methods: {
        submitForm() {
            const clientID = this.$route.params.id;
            axios
                .patch(`/api/v1/clients/${clientID}/`, this.client)
                //eslint-disable-next-line
                .then(response => {
                    this.$router.push('/dashboard/clients');
                })
                .catch(error => {
                    console.log(JSON.stringify(error));
                    this.errors = error.response.data.errors;
                });
        },
        getClient(){
            const clientID = this.$route.params.id;
            console.log(clientID);
            axios
                .get(`/api/v1/clients/${clientID}`,)
                .then(response => {
                    this.client = response.data;

                })
                .catch((error) => {
                    console.log(JSON.stringify(error));
                })
        }


    }
}
</script>

<style scoped>

</style>
